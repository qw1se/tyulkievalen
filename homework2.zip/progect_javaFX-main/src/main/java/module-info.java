module kg.mega.project_javafx_1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.apache.poi.ooxml;
    requires java.desktop;


    opens project_glovo to javafx.fxml;
    exports project_glovo;
}